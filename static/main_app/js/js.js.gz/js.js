<<<<<<< HEAD
$(function () {

    // $(".navbar-brand").click(function () {
    //     $(this).css({'color':'red'})
    // });

    // let d = $(".navbar-brand").text()
    // alert(d+', Привет')


    // attrs

   // let g = $('.nav :first, .nav-sidebar :first').text()
   //  console.log(g)

    // $('a[href="#"]').css({'color':'red'})

    // $('button').click(function () {
    //     console.log('Привет')
    // })

    // $('button').hide(1000)


})


// $(function(){
//     $('[data-toggle="tooltip"]').tooltip();
//     $(".collapse").on("hide.bs.collapse", function() {
//
//         $(this).prev().find(".fa").eq(1).removeClass("fa-angle-right").addClass("fa-angle-down");
//     });
//     $('.collapse').on("show.bs.collapse", function() {
//         console.log('ff')
//         $(this).prev().find(".fa").eq(1).removeClass("fa-angle-down").addClass("fa-angle-right");
//     });
// })

=======
$(function () {

    // $(".navbar-brand").click(function () {
    //     $(this).css({'color':'red'})
    // });

    // let d = $(".navbar-brand").text()
    // alert(d+', Привет')


    // attrs

   // let g = $('.nav :first, .nav-sidebar :first').text()
   //  console.log(g)

    // $('a[href="#"]').css({'color':'red'})

    // $('button').click(function () {
    //     console.log('Привет')
    // })

    // $('button').hide(1000)


})


$(function(){
    $('[data-toggle="tooltip"]').tooltip();
    $(".collapse").on("hide.bs.collapse", function() {

        $(this).prev().find(".fa").eq(1).removeClass("fa-angle-right").addClass("fa-angle-down");
    });
    $('.collapse').on("show.bs.collapse", function() {
        console.log('ff')
        $(this).prev().find(".fa").eq(1).removeClass("fa-angle-down").addClass("fa-angle-right");
    });
})

>>>>>>> e4da988e14862b2ef518ee354184a3e0eeeffc69
